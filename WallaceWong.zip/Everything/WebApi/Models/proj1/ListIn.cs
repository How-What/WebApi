﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApi.Models.proj1
{
    public class ListIn
    {
        public int[] InList { get; set; }

        public ListIn() { }
    }
}